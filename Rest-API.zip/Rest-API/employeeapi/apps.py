from django.apps import AppConfig


class EmployeeapiConfig(AppConfig):
    name = 'employeeapi'
