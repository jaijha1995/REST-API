from rest_framework import viewsets
from . import models
from . import serializers

class LabViewset(viewsets.ModelViewSet):
    queryset = models.Lab.objects.all()
    serializer_class = serializers.labSerializer