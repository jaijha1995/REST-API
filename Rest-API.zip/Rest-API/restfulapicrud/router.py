from employeeapi.viewsets import LabViewset
from rest_framework import routers

router = routers.DefaultRouter()
router.register('Lab',LabViewset)

# localhost:p/api/employee/5
# GET, POST, PUT, DELETE
# list , retrive